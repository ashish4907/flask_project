from flask import Flask, render_template, request, redirect, url_for
import random
from flask_sqlalchemy import SQLAlchemy


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///test.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)


class Url(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    original_url = db.Column(db.String(120))
    short_url = db.Column(db.String(120))

    def __init__(self, original_url, short_url):
        self.original_url = original_url
        self.short_url = short_url


@app.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        original_url = request.form.get('url')
        short_url = "".join(random.choice(
            '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*_+=<>') for i in range(10))
        url = Url.query.filter_by(original_url=original_url).first()
        if url:
            return redirect(url_for('home'))
        else:
            url = Url(original_url, short_url)
            db.session.add(url)
            db.session.commit()
            return redirect(url_for('home'))
    else:
        urls = Url.query.order_by(Url.id.desc()).limit(1)
        return render_template('home.html', urls=urls)


@app.route('/history')
def history():
    urls = Url.query.order_by(Url.id.desc()).all()
    return render_template('history.html', urls=urls)


@app.route('/<short_url>')
def redirect_short_url(short_url):
    original_url = Url.query.filter_by(short_url=short_url).first()
    if original_url:
        return redirect(original_url.original_url)
    else:
        return 'URL not found'


@app.route('/delete/<int:id>', methods=['GET', 'POST'])
def delete(id):
    url = Url.query.filter_by(id=id).first()
    if url:
        db.session.delete(url)
        db.session.commit()
        return redirect(url_for('history'))
    else:
        return 'URL not found'




if __name__ == '__main__':
    app.run(debug=True)
